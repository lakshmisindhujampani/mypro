package com.cg.lakshmisindhu.service;

import java.util.Map;

import com.cg.lakshmisindhu.bean.TransportBean;
import com.cg.lakshmisindhu.exception.TransportException;

public interface ITransportService {

	Map<String, String> getTransportDetails()throws TransportException;
	void addTransport(TransportBean bean)throws TransportException;
	
}
