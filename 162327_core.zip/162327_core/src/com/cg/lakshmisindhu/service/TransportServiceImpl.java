package com.cg.lakshmisindhu.service;

import java.util.Map;

import com.cg.lakshmisindhu.bean.TransportBean;
import com.cg.lakshmisindhu.dao.ITransportDao;
import com.cg.lakshmisindhu.dao.TransportDaoImpl;
import com.cg.lakshmisindhu.exception.TransportException;
import com.cg.lakshmisindhu.util.DataBase;

public class TransportServiceImpl implements ITransportService {

	ITransportDao dao = new TransportDaoImpl();
	@Override
	public Map<String, String> getTransportDetails() throws TransportException {
	
		return dao.getTransportDetails();
	}
	@Override
	public void addTransport(TransportBean bean) throws TransportException {
		dao.addTransport(bean);
		
	}
	

}
