package com.cg.lakshmisindhu.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;
import com.cg.lakshmisindhu.bean.TransportBean;
import com.cg.lakshmisindhu.exception.TransportException;
import com.cg.lakshmisindhu.service.TransportServiceImpl;
import com.cg.lakshmisindhu.service.ITransportService;

public class Client {

	public static void main(String[] args) throws TransportException {
		ITransportService service= new TransportServiceImpl();
		Scanner scanner = new Scanner(System.in);
		try {
				TransportBean bean = new TransportBean();
				Map<String, String> transportDetails = service.getTransportDetails();
				System.out.println("Mode of Transport");
				int count = 1;
				for (Map.Entry<String, String> entryset : transportDetails.entrySet()) {
					System.out.println(count + ". " + entryset.getValue());
					count++;
				}
				System.out.println("Enter Option");
				int choice = scanner.nextInt();
				int count1 = 1;
				for (Map.Entry<String, String> entryset : transportDetails.entrySet()) {
					if(choice==count) {
						bean.setTransportCategoryId(entryset.getKey());
					}
					count1++;
				}
				int id = (int) (Math.random()*10000);
				bean.setId(id);
				System.out.println("Enter Reason : ");
				scanner.nextLine();
				String reason = scanner.nextLine();
				bean.setReason(reason);
				System.out.println("When:\n1.This Week\n2. Next Week\n3.Next Month");
				int whenchoice = scanner.nextInt();
				if(whenchoice==1)
				{
					bean.setWhen("This Week");
				}
				if (whenchoice ==2) {
					bean.setWhen("Next Week");	
				}
				if (whenchoice ==3) {
					bean.setWhen("Next Month");	
				}
				service.addTransport(bean);
				LocalDateTime ldt = LocalDateTime.now();
				DateTimeFormatter f = DateTimeFormatter.ofPattern("dd MMMM yyyy hh:mm a");
				System.out.println("Booked with id "+ id + "on "+ ldt.format(f));
		
		}catch (Exception e) 
		{
			System.out.println(" internal error. try later.");
		}
		
	}
}

