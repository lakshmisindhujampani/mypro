package com.cg.lakshmisindhu.dao;

import java.util.Map;

import com.cg.lakshmisindhu.bean.TransportBean;
import com.cg.lakshmisindhu.exception.TransportException;

public interface ITransportDao {

	Map<String, String> getTransportDetails()throws TransportException;

	void addTransport(TransportBean bean) throws TransportException;
	

	
}
