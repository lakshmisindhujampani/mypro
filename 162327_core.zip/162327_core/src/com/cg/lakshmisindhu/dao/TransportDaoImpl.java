package com.cg.lakshmisindhu.dao;

import java.util.Map;

import com.cg.lakshmisindhu.bean.TransportBean;
import com.cg.lakshmisindhu.util.DataBase;

public class TransportDaoImpl implements ITransportDao {

	@Override
	public Map<String, String> getTransportDetails() {
		
		return DataBase.getTransportDetails();
	}

	@Override
	public void addTransport(TransportBean bean) {
		DataBase.addTransport(bean);
	}
	
}
